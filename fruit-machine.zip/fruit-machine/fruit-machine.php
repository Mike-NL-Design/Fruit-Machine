<?php
/**
 * Plugin Name: Fruit Machine
 * Plugin URI: https://github.com/Mike-NL-Design/
 * Description: Fruit machine slot game with user management, daily spins, and leaderboard
 * Version: 2.5
 * Author: MikeNL
 */

if (!defined('ABSPATH')) exit;

class FruitMachine {
    
    private $table_name;
    private $stats_table;
    private $history_table;
    private $db_version = '2.4';
    
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'fruit_machine_users';
        $this->stats_table = $wpdb->prefix . 'fruit_machine_stats';
        $this->history_table = $wpdb->prefix . 'fruit_machine_history';
        
        // Load text domain for translations
        add_action('init', array($this, 'load_textdomain'));
        
        // Create database tables on activation
        register_activation_hook(__FILE__, array($this, 'create_tables'));
        
        // Update database on version change
        add_action('plugins_loaded', array($this, 'check_db_version'));
        
        // Add admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));
        
        // Enqueue scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        
        // Add shortcode
        add_shortcode('fruit_machine', array($this, 'shortcode'));
        
        // REST API endpoints
        add_action('rest_api_init', array($this, 'register_rest_routes'));
        
        // User login check
        add_action('template_redirect', array($this, 'check_user_access'));
        
        // Add Buy Me A Coffee link to content
        add_filter('the_content', array($this, 'add_buy_me_coffee_to_content'));
        
        // Handle language submission
        add_action('wp_ajax_fruit_machine_set_language', array($this, 'ajax_set_language'));
        add_action('wp_ajax_nopriv_fruit_machine_set_language', array($this, 'ajax_nopriv_handler'));
        
        // Handle spin history
        add_action('wp_ajax_fruit_machine_get_history', array($this, 'ajax_get_history'));
        
        // Handle user deletion
        add_action('delete_user', array($this, 'delete_user_data'));
        
        // Activation notice
        add_action('admin_notices', array($this, 'show_activation_notice'));
        
        // Add export functionality
        add_action('admin_init', array($this, 'handle_export'));
    }
    
    // Load text domain
    public function load_textdomain() {
        load_plugin_textdomain('fruit-machine', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }
    
    // Create database tables
    public function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Users table
        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            id INT(11) NOT NULL AUTO_INCREMENT,
            user_id INT(11) NOT NULL,
            language VARCHAR(10) DEFAULT 'en',
            daily_spins_used INT(11) DEFAULT 0,
            total_spins INT(11) DEFAULT 0,
            total_wins DECIMAL(10,2) DEFAULT 0.00,
            bmac_spins INT(11) DEFAULT 0,
            last_spin_date DATE NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY user_id (user_id),
            INDEX idx_user_spins (user_id, last_spin_date),
            INDEX idx_daily_spins (last_spin_date, daily_spins_used)
        ) $charset_collate;";
        
        // Stats table for leaderboard
        $sql2 = "CREATE TABLE IF NOT EXISTS {$this->stats_table} (
            id INT(11) NOT NULL AUTO_INCREMENT,
            user_id INT(11) NOT NULL,
            month_year VARCHAR(7) NOT NULL,
            total_wins DECIMAL(10,2) DEFAULT 0.00,
            total_spins INT(11) DEFAULT 0,
            best_single_win DECIMAL(10,2) DEFAULT 0.00,
            PRIMARY KEY (id),
            UNIQUE KEY user_month (user_id, month_year),
            INDEX idx_month_year (month_year)
        ) $charset_collate;";
        
        // History table
        $sql3 = "CREATE TABLE IF NOT EXISTS {$this->history_table} (
            id INT(11) NOT NULL AUTO_INCREMENT,
            user_id INT(11) NOT NULL,
            spin_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            bet_amount DECIMAL(10,2) NOT NULL,
            win_amount DECIMAL(10,2) DEFAULT 0.00,
            symbols VARCHAR(255) NOT NULL,
            ip_address VARCHAR(45),
            user_agent TEXT,
            PRIMARY KEY (id),
            INDEX idx_user_date (user_id, spin_date),
            INDEX idx_date (spin_date)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        dbDelta($sql2);
        dbDelta($sql3);
        
        // Add default options
        add_option('fruit_machine_daily_spins', 25);
        add_option('fruit_machine_bmac_spins', 1500);
        add_option('fruit_machine_bmac_url', 'https://buymeacoffee.com/nlbiertjenl');
        add_option('fruit_machine_leaderboard_reset', 'monthly');
        add_option('fruit_machine_db_version', $this->db_version);
        add_option('fruit_machine_activation_notice', true);
    }
    
    // Check database version
    public function check_db_version() {
        if (get_option('fruit_machine_db_version') != $this->db_version) {
            $this->create_tables();
        }
    }
    
    // Show activation notice
    public function show_activation_notice() {
        if (get_option('fruit_machine_activation_notice')) {
            ?>
            <div class="notice notice-success is-dismissible">
                <p><?php _e('Fruit Machine plugin activated! Add the [fruit_machine] shortcode to a page to get started.', 'fruit-machine'); ?></p>
                <p><a href="<?php echo admin_url('admin.php?page=fruit-machine-settings'); ?>"><?php _e('Configure Settings', 'fruit-machine'); ?></a></p>
            </div>
            <?php
            delete_option('fruit_machine_activation_notice');
        }
    }
    
    // Add admin menu
    public function add_admin_menu() {
        add_menu_page(
            __('Fruit Machine Settings', 'fruit-machine'),
            __('Fruit Machine', 'fruit-machine'),
            'manage_options',
            'fruit-machine-settings',
            array($this, 'admin_settings_page'),
            'dashicons-games',
            30
        );
        
        add_submenu_page(
            'fruit-machine-settings',
            __('User Statistics', 'fruit-machine'),
            __('User Stats', 'fruit-machine'),
            'manage_options',
            'fruit-machine-stats',
            array($this, 'admin_stats_page')
        );
    }
    
    // Admin settings page
    public function admin_settings_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'fruit-machine'));
        }
        
        // Save settings
        if (isset($_POST['save_settings']) && check_admin_referer('fruit_machine_settings')) {
            // Validate and sanitize inputs
            $daily_spins = absint($_POST['daily_spins']);
            $bmac_spins = absint($_POST['bmac_spins']);
            $bmac_url = esc_url_raw($_POST['bmac_url']);
            $leaderboard_reset = sanitize_text_field($_POST['leaderboard_reset']);
            
            // Validate bet amounts
            $bet_amounts_str = sanitize_text_field($_POST['bet_amounts']);
            $bet_amounts = array_map('absint', explode(',', $bet_amounts_str));
            $bet_amounts = array_filter($bet_amounts);
            sort($bet_amounts);
            
            if ($daily_spins < 1) {
                echo '<div class="notice notice-error"><p>' . __('Daily spins must be at least 1.', 'fruit-machine') . '</p></div>';
            } elseif ($bmac_spins < 1) {
                echo '<div class="notice notice-error"><p>' . __('BMAC spins must be at least 1.', 'fruit-machine') . '</p></div>';
            } elseif (empty($bet_amounts)) {
                echo '<div class="notice notice-error"><p>' . __('Bet amounts are required.', 'fruit-machine') . '</p></div>';
            } else {
                update_option('fruit_machine_daily_spins', $daily_spins);
                update_option('fruit_machine_bmac_spins', $bmac_spins);
                update_option('fruit_machine_bmac_url', $bmac_url);
                update_option('fruit_machine_leaderboard_reset', $leaderboard_reset);
                update_option('fruit_machine_bet_amounts', $bet_amounts);
                
                echo '<div class="notice notice-success"><p>' . __('Settings saved!', 'fruit-machine') . '</p></div>';
            }
        }
        
        // Handle BMAC manual spin addition
        if (isset($_POST['add_bmac_spins']) && check_admin_referer('fruit_machine_bmac_manual', 'bmac_nonce')) {
            $user_id = absint($_POST['bmac_user']);
            $spins_to_add = absint($_POST['bmac_spins_to_add']);
            $payment_ref = sanitize_text_field($_POST['bmac_payment_id']);
            $notes = sanitize_textarea_field($_POST['bmac_notes']);
            
            if ($user_id < 1) {
                echo '<div class="notice notice-error"><p>' . __('Please select a user.', 'fruit-machine') . '</p></div>';
            } elseif ($spins_to_add < 1) {
                echo '<div class="notice notice-error"><p>' . __('Spins must be at least 1.', 'fruit-machine') . '</p></div>';
            } else {
                // Add spins to user
                global $wpdb;
                
                // Update user's BMAC spins
                $wpdb->query($wpdb->prepare(
                    "UPDATE {$this->table_name} 
                     SET bmac_spins = bmac_spins + %d 
                     WHERE user_id = %d",
                    $spins_to_add,
                    $user_id
                ));
                
                // Record transaction in history
                $wpdb->insert(
                    $this->history_table,
                    array(
                        'user_id' => $user_id,
                        'bet_amount' => 0,
                        'win_amount' => 0,
                        'symbols' => 'BMAC_PURCHASE',
                        'ip_address' => $payment_ref ?: 'manual_admin',
                        'user_agent' => $spins_to_add . ' spins - ' . ($notes ?: 'Admin added')
                    )
                );
                
                // Get user info for message
                $user = get_userdata($user_id);
                $user_name = $user ? $user->display_name : 'User #' . $user_id;
                
                echo '<div class="notice notice-success"><p>' . 
                     sprintf(__('Successfully added %d BMAC spins to %s.', 'fruit-machine'), $spins_to_add, $user_name) . 
                     '</p></div>';
                
                // Optional: Send email notification to user
                if ($user && $user->user_email) {
                    $subject = sprintf(__('[%s] BMAC Spins Added', 'fruit-machine'), get_bloginfo('name'));
                    $message = sprintf(__(
                        'Hello %s,
                        
Thank you for your Buy Me A Coffee support!
                        
We have added %d extra spins to your Fruit Machine account.
                        
You can now play with these extra spins on: %s
                        
Thank you for your support!
                        
The %s Team', 'fruit-machine'), 
                        $user_name, 
                        $spins_to_add,
                        home_url(),
                        get_bloginfo('name')
                    );
                    
                    wp_mail($user->user_email, $subject, $message);
                }
            }
        }
        
        // Get current settings
        $daily_spins = get_option('fruit_machine_daily_spins', 25);
        $bmac_spins = get_option('fruit_machine_bmac_spins', 1500);
        $bmac_url = get_option('fruit_machine_bmac_url', 'https://buymeacoffee.com/nlbiertjenl');
        $leaderboard_reset = get_option('fruit_machine_leaderboard_reset', 'monthly');
        $bet_amounts = get_option('fruit_machine_bet_amounts', array(1, 5, 10, 25));
        
        ?>
        <div class="wrap">
            <h1><?php _e('Fruit Machine Settings', 'fruit-machine'); ?></h1>
            
            <form method="post" action="">
                <?php wp_nonce_field('fruit_machine_settings'); ?>
                
                <h2><?php _e('Game Settings', 'fruit-machine'); ?></h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="daily_spins"><?php _e('Daily Free Spins', 'fruit-machine'); ?></label></th>
                        <td>
                            <input type="number" id="daily_spins" name="daily_spins" 
                                   value="<?php echo esc_attr($daily_spins); ?>" class="regular-text" min="1">
                            <p class="description"><?php _e('Number of free spins users get per day', 'fruit-machine'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="bet_amounts"><?php _e('Bet Amounts', 'fruit-machine'); ?></label></th>
                        <td>
                            <input type="text" id="bet_amounts" name="bet_amounts" 
                                   value="<?php echo esc_attr(implode(',', $bet_amounts)); ?>" class="regular-text">
                            <p class="description"><?php _e('Comma-separated list of bet amounts (e.g., 1,5,10,25)', 'fruit-machine'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="bmac_spins"><?php _e('Buy Me A Coffee Spins', 'fruit-machine'); ?></label></th>
                        <td>
                            <input type="number" id="bmac_spins" name="bmac_spins" 
                                   value="<?php echo esc_attr($bmac_spins); ?>" class="regular-text" min="1">
                            <p class="description"><?php _e('Total spins users get after Buy Me A Coffee payment', 'fruit-machine'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="bmac_url"><?php _e('Buy Me A Coffee URL', 'fruit-machine'); ?></label></th>
                        <td>
                            <input type="url" id="bmac_url" name="bmac_url" 
                                   value="<?php echo esc_url($bmac_url); ?>" class="regular-text">
                            <p class="description"><?php _e('Your Buy Me A Coffee page URL', 'fruit-machine'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="leaderboard_reset"><?php _e('Leaderboard Reset', 'fruit-machine'); ?></label></th>
                        <td>
                            <select id="leaderboard_reset" name="leaderboard_reset" class="regular-text">
                                <option value="monthly" <?php selected($leaderboard_reset, 'monthly'); ?>><?php _e('Monthly', 'fruit-machine'); ?></option>
                                <option value="weekly" <?php selected($leaderboard_reset, 'weekly'); ?>><?php _e('Weekly', 'fruit-machine'); ?></option>
                                <option value="never" <?php selected($leaderboard_reset, 'never'); ?>><?php _e('Never', 'fruit-machine'); ?></option>
                            </select>
                            <p class="description"><?php _e('How often to reset the leaderboard', 'fruit-machine'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><?php _e('Current Statistics', 'fruit-machine'); ?></th>
                        <td>
                            <?php
                            global $wpdb;
                            $total_users = $wpdb->get_var("SELECT COUNT(*) FROM {$this->table_name}");
                            $total_spins = $wpdb->get_var("SELECT SUM(total_spins) FROM {$this->table_name}");
                            $active_today = $wpdb->get_var($wpdb->prepare(
                                "SELECT COUNT(*) FROM {$this->table_name} WHERE last_spin_date = %s",
                                date('Y-m-d')
                            ));
                            $total_wins = $wpdb->get_var("SELECT SUM(total_wins) FROM {$this->table_name}");
                            ?>
                            <ul>
                                <li><?php printf(__('Total Registered Players: %d', 'fruit-machine'), intval($total_users)); ?></li>
                                <li><?php printf(__('Total Spins Played: %d', 'fruit-machine'), intval($total_spins)); ?></li>
                                <li><?php printf(__('Total Amount Won: $%s', 'fruit-machine'), number_format($total_wins, 2)); ?></li>
                                <li><?php printf(__('Active Players Today: %d', 'fruit-machine'), intval($active_today)); ?></li>
                            </ul>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" name="save_settings" class="button-primary" value="<?php _e('Save Settings', 'fruit-machine'); ?>">
                    <a href="<?php echo admin_url('admin.php?page=fruit-machine-settings&action=reset_leaderboard'); ?>" 
                       class="button" onclick="return confirm('<?php _e('Are you sure you want to reset the leaderboard?', 'fruit-machine'); ?>')">
                       <?php _e('Reset Leaderboard Now', 'fruit-machine'); ?>
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=fruit-machine-settings&export=leaderboard'); ?>" 
                       class="button">
                       <?php _e('Export Leaderboard', 'fruit-machine'); ?>
                    </a>
                </p>
            </form>
            
            <h2><?php _e('Leaderboard (Current Month)', 'fruit-machine'); ?></h2>
            <?php $this->display_leaderboard(); ?>

            <h2><?php _e('Buy Me A Coffee - Manual Management', 'fruit-machine'); ?></h2>

            <form method="post" action="">
                <?php wp_nonce_field('fruit_machine_bmac_manual', 'bmac_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="bmac_user"><?php _e('Select User', 'fruit-machine'); ?></label></th>
                        <td>
                            <?php wp_dropdown_users(array(
                                'name' => 'bmac_user',
                                'show_option_all' => __('Select a user...', 'fruit-machine'),
                                'id' => 'bmac_user',
                                'class' => 'regular-text'
                            )); ?>
                            <p class="description"><?php _e('Select user to add BMAC spins to', 'fruit-machine'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="bmac_spins_to_add"><?php _e('Spins to Add', 'fruit-machine'); ?></label></th>
                        <td>
                            <input type="number" id="bmac_spins_to_add" name="bmac_spins_to_add" 
                                   value="<?php echo esc_attr(get_option('fruit_machine_bmac_spins', 1500)); ?>" 
                                   class="regular-text" min="1">
                            <p class="description"><?php _e('Number of spins to add (default: 1500)', 'fruit-machine'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="bmac_payment_id"><?php _e('Payment Reference', 'fruit-machine'); ?></label></th>
                        <td>
                            <input type="text" id="bmac_payment_id" name="bmac_payment_id" 
                                   class="regular-text" placeholder="<?php _e('e.g., bmac_123456', 'fruit-machine'); ?>">
                            <p class="description"><?php _e('Optional: Payment ID/Reference from Buy Me A Coffee email', 'fruit-machine'); ?></p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row"><label for="bmac_notes"><?php _e('Notes', 'fruit-machine'); ?></label></th>
                        <td>
                            <textarea id="bmac_notes" name="bmac_notes" rows="3" class="large-text"></textarea>
                            <p class="description"><?php _e('Optional: Notes about this payment', 'fruit-machine'); ?></p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" name="add_bmac_spins" class="button-primary" 
                           value="<?php _e('Add BMAC Spins to User', 'fruit-machine'); ?>">
                </p>
            </form>

            <h3><?php _e('Recent BMAC Transactions', 'fruit-machine'); ?></h3>
            <?php
            // Display recent BMAC transactions
            global $wpdb;
            $recent_bmac = $wpdb->get_results("
                SELECT * FROM {$this->history_table} 
                WHERE symbols = 'BMAC_PURCHASE' 
                ORDER BY spin_date DESC 
                LIMIT 10
            ");

            if ($recent_bmac) {
                echo '<table class="wp-list-table widefat fixed striped">';
                echo '<thead><tr>
                    <th>' . __('Date', 'fruit-machine') . '</th>
                    <th>' . __('User', 'fruit-machine') . '</th>
                    <th>' . __('Spins Added', 'fruit-machine') . '</th>
                    <th>' . __('Payment Ref', 'fruit-machine') . '</th>
                </tr></thead><tbody>';
                
                foreach ($recent_bmac as $transaction) {
                    $user = get_userdata($transaction->user_id);
                    $user_name = $user ? $user->display_name : 'User #' . $transaction->user_id;
                    
                    // Extract spins added from user_agent field
                    $spins_added = !empty($transaction->user_agent) ? $transaction->user_agent : '1500';
                    
                    echo '<tr>';
                    echo '<td>' . date_i18n(get_option('date_format'), strtotime($transaction->spin_date)) . '</td>';
                    echo '<td>' . esc_html($user_name) . '</td>';
                    echo '<td>' . esc_html($spins_added) . '</td>';
                    echo '<td>' . esc_html($transaction->ip_address) . '</td>';
                    echo '</tr>';
                }
                
                echo '</tbody></table>';
            } else {
                echo '<p>' . __('No BMAC transactions yet.', 'fruit-machine') . '</p>';
            }
            ?>
        </div>
        <?php
    }
    
    // Admin stats page
    public function admin_stats_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'fruit-machine'));
        }
        
        global $wpdb;
        
        // Get filter parameters
        $filter_date = isset($_GET['date']) ? sanitize_text_field($_GET['date']) : date('Y-m-d');
        $filter_user = isset($_GET['user_id']) ? absint($_GET['user_id']) : 0;
        
        // Build query
        $where = array('1=1');
        $params = array();
        
        if ($filter_date) {
            $where[] = "DATE(h.spin_date) = %s";
            $params[] = $filter_date;
        }
        
        if ($filter_user) {
            $where[] = "h.user_id = %d";
            $params[] = $filter_user;
        }
        
        $where_clause = implode(' AND ', $where);
        
        // Get statistics
        $stats = $wpdb->get_row($wpdb->prepare(
            "SELECT 
                COUNT(*) as total_spins,
                SUM(h.bet_amount) as total_bets,
                SUM(h.win_amount) as total_wins,
                AVG(h.win_amount) as avg_win,
                MAX(h.win_amount) as max_win
             FROM {$this->history_table} h
             WHERE {$where_clause}",
            $params
        ));
        
        ?>
        <div class="wrap">
            <h1><?php _e('Fruit Machine Statistics', 'fruit-machine'); ?></h1>
            
            <form method="get" action="">
                <input type="hidden" name="page" value="fruit-machine-stats">
                
                <table class="form-table">
                    <tr>
                        <th><label for="date"><?php _e('Date', 'fruit-machine'); ?></label></th>
                        <td><input type="date" id="date" name="date" value="<?php echo esc_attr($filter_date); ?>"></td>
                    </tr>
                    <tr>
                        <th><label for="user_id"><?php _e('User', 'fruit-machine'); ?></label></th>
                        <td>
                            <?php wp_dropdown_users(array(
                                'name' => 'user_id',
                                'show_option_all' => __('All Users', 'fruit-machine'),
                                'selected' => $filter_user
                            )); ?>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" class="button-primary" value="<?php _e('Filter', 'fruit-machine'); ?>">
                </p>
            </form>
            
            <h2><?php _e('Summary Statistics', 'fruit-machine'); ?></h2>
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th><?php _e('Total Spins', 'fruit-machine'); ?></th>
                        <th><?php _e('Total Bets', 'fruit-machine'); ?></th>
                        <th><?php _e('Total Wins', 'fruit-machine'); ?></th>
                        <th><?php _e('Average Win', 'fruit-machine'); ?></th>
                        <th><?php _e('Maximum Win', 'fruit-machine'); ?></th>
                        <th><?php _e('Net Profit', 'fruit-machine'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo intval($stats->total_spins); ?></td>
                        <td>$<?php echo number_format($stats->total_bets, 2); ?></td>
                        <td>$<?php echo number_format($stats->total_wins, 2); ?></td>
                        <td>$<?php echo number_format($stats->avg_win, 2); ?></td>
                        <td>$<?php echo number_format($stats->max_win, 2); ?></td>
                        <td>$<?php echo number_format($stats->total_bets - $stats->total_wins, 2); ?></td>
                    </tr>
                </tbody>
            </table>
            
            <h2><?php _e('Recent Spins', 'fruit-machine'); ?></h2>
            <?php
            $recent_spins = $wpdb->get_results($wpdb->prepare(
                "SELECT h.*, u.user_login, u.display_name 
                 FROM {$this->history_table} h
                 LEFT JOIN {$wpdb->users} u ON h.user_id = u.ID
                 WHERE {$where_clause}
                 ORDER BY h.spin_date DESC
                 LIMIT 50",
                $params
            ));
            
            if ($recent_spins) {
                ?>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th><?php _e('Date/Time', 'fruit-machine'); ?></th>
                            <th><?php _e('Player', 'fruit-machine'); ?></th>
                            <th><?php _e('Bet', 'fruit-machine'); ?></th>
                            <th><?php _e('Win', 'fruit-machine'); ?></th>
                            <th><?php _e('Symbols', 'fruit-machine'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_spins as $spin): ?>
                        <tr>
                            <td><?php echo date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($spin->spin_date)); ?></td>
                            <td><?php echo esc_html($spin->display_name ?: $spin->user_login); ?></td>
                            <td>$<?php echo number_format($spin->bet_amount, 2); ?></td>
                            <td>$<?php echo number_format($spin->win_amount, 2); ?></td>
                            <td><?php echo esc_html($spin->symbols); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php
            } else {
                echo '<p>' . __('No spins found for the selected criteria.', 'fruit-machine') . '</p>';
            }
            ?>
        </div>
        <?php
    }
    
    // Handle export
    public function handle_export() {
        if (!isset($_GET['export']) || $_GET['export'] !== 'leaderboard' || !current_user_can('manage_options')) {
            return;
        }
        
        if (!isset($_GET['page']) || $_GET['page'] !== 'fruit-machine-settings') {
            return;
        }
        
        $this->export_leaderboard_csv();
    }
    
    // Export leaderboard to CSV
    private function export_leaderboard_csv() {
        global $wpdb;
        
        $current_month = date('Y-m');
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT s.user_id, s.total_wins, s.total_spins, s.best_single_win, u.display_name, u.user_email 
             FROM {$this->stats_table} s 
             LEFT JOIN {$wpdb->users} u ON s.user_id = u.ID 
             WHERE s.month_year = %s 
             ORDER BY s.total_wins DESC",
            $current_month
        ));
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=leaderboard-' . $current_month . '.csv');
        
        $output = fopen('php://output', 'w');
        
        // Add BOM for UTF-8
        fwrite($output, "\xEF\xBB\xBF");
        
        // Headers
        fputcsv($output, array(
            __('Rank', 'fruit-machine'),
            __('Player', 'fruit-machine'),
            __('Email', 'fruit-machine'),
            __('Total Wins', 'fruit-machine'),
            __('Total Spins', 'fruit-machine'),
            __('Best Single Win', 'fruit-machine')
        ));
        
        // Data
        $rank = 1;
        foreach ($results as $row) {
            fputcsv($output, array(
                $rank,
                $row->display_name ?: 'User #' . $row->user_id,
                $row->user_email ?: '',
                $row->total_wins,
                $row->total_spins,
                $row->best_single_win
            ));
            $rank++;
        }
        
        fclose($output);
        exit;
    }
    
    // Display leaderboard
    private function display_leaderboard() {
        global $wpdb;
        
        $current_month = date('Y-m');
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT s.user_id, s.total_wins, s.total_spins, s.best_single_win, u.display_name 
             FROM {$this->stats_table} s 
             LEFT JOIN {$wpdb->users} u ON s.user_id = u.ID 
             WHERE s.month_year = %s 
             ORDER BY s.total_wins DESC 
             LIMIT 10",
            $current_month
        ));
        
        if (empty($results)) {
            echo '<p>' . __('No leaderboard data yet for this month.', 'fruit-machine') . '</p>';
            return;
        }
        
        echo '<table class="wp-list-table widefat fixed striped">';
        echo '<thead><tr>
            <th>' . __('Rank', 'fruit-machine') . '</th>
            <th>' . __('Player', 'fruit-machine') . '</th>
            <th>' . __('Total Wins', 'fruit-machine') . '</th>
            <th>' . __('Spins', 'fruit-machine') . '</th>
            <th>' . __('Best Win', 'fruit-machine') . '</th>
        </tr></thead>';
        echo '<tbody>';
        
        $rank = 1;
        foreach ($results as $row) {
            echo '<tr>';
            echo '<td>' . $rank . '</td>';
            echo '<td>' . esc_html($row->display_name ?: __('User #', 'fruit-machine') . $row->user_id) . '</td>';
            echo '<td>$' . number_format($row->total_wins, 2) . '</td>';
            echo '<td>' . number_format($row->total_spins) . '</td>';
            echo '<td>$' . number_format($row->best_single_win ?: 0, 2) . '</td>';
            echo '</tr>';
            $rank++;
        }
        
        echo '</tbody></table>';
    }
    
    // Enqueue frontend scripts
    public function enqueue_scripts() {
        // Frontend CSS
        wp_enqueue_style(
            'fruit-machine-css',
            plugin_dir_url(__FILE__) . 'assets/css/frontend.css',
            array(),
            filemtime(plugin_dir_path(__FILE__) . 'assets/css/frontend.css')
        );
        
        // Frontend JS
        wp_enqueue_script(
            'fruit-machine-js',
            plugin_dir_url(__FILE__) . 'assets/js/frontend.js',
            array('jquery'),
            filemtime(plugin_dir_path(__FILE__) . 'assets/js/frontend.js'),
            true
        );
        
        // Localize script for AJAX
        wp_localize_script('fruit-machine-js', 'fruitMachineAjax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'rest_url' => esc_url_raw(rest_url('fruit-machine/v1/')),
            'nonce' => wp_create_nonce('wp_rest'),
            'user_id' => get_current_user_id(),
            'is_logged_in' => is_user_logged_in(),
            'daily_spins' => get_option('fruit_machine_daily_spins', 25),
            'bmac_spins' => get_option('fruit_machine_bmac_spins', 1500),
            'bmac_url' => get_option('fruit_machine_bmac_url', 'https://buymeacoffee.com/nlbiertjenl'),
            'bet_amounts' => get_option('fruit_machine_bet_amounts', array(1, 5, 10, 25)),
            'plugin_url' => plugin_dir_url(__FILE__),
            'i18n' => array(
                'spinning' => __('Spinning...', 'fruit-machine'),
                'spin' => __('SPIN', 'fruit-machine'),
                'no_spins' => __('No spins left! Buy extra spins via Buy Me A Coffee.', 'fruit-machine'),
                'auto' => __('AUTO', 'fruit-machine'),
                'stop_auto' => __('STOP AUTO', 'fruit-machine'),
                'loading' => __('Loading...', 'fruit-machine'),
                'failed' => __('Failed to load', 'fruit-machine'),
                'win' => __('WIN', 'fruit-machine')
            )
        ));
    }
    
    // Enqueue admin scripts
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'fruit-machine') === false) {
            return;
        }
        
        wp_enqueue_style(
            'fruit-machine-admin-css',
            plugin_dir_url(__FILE__) . 'assets/css/admin.css',
            array(),
            filemtime(plugin_dir_path(__FILE__) . 'assets/css/admin.css')
        );
        
        if ($hook === 'toplevel_page_fruit-machine-settings') {
            wp_enqueue_script('jquery-ui-datepicker');
            wp_enqueue_style('jquery-ui-css', 'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
        }
    }
    
    // Shortcode for the game
    public function shortcode($atts = array()) {
        $atts = shortcode_atts(array(
            'show_login_message' => true,
            'redirect_url' => wp_login_url(get_permalink()),
        ), $atts, 'fruit_machine');
        
        if (!is_user_logged_in()) {
            if (!$atts['show_login_message']) {
                return '';
            }
            
            $login_message = '
            <div class="fruit-machine-login-required">
                <h2>' . __('🎰 Fruit Machine', 'fruit-machine') . '</h2>
                <div class="login-message">
                    <p>' . __('Please log in to play the Fruit Machine game!', 'fruit-machine') . '</p>
                    <p><a href="' . esc_url($atts['redirect_url']) . '" class="login-button">' . __('Login', 'fruit-machine') . '</a></p>
                    <p>' . __('Don\'t have an account?', 'fruit-machine') . ' <a href="' . wp_registration_url() . '">' . __('Register here', 'fruit-machine') . '</a></p>
                </div>
                <div class="support-message">
                    <p>' . __('Support us via Buy Me A Coffee →', 'fruit-machine') . ' <a href="https://buymeacoffee.com/nlbiertjenl" target="_blank">https://buymeacoffee.com/nlbiertjenl</a></p>
                </div>
            </div>';
            
            return $login_message;
        }
        
        $user_id = get_current_user_id();
        $user_data = $this->get_user_data($user_id);
        
        return $this->game_interface($user_data);
    }
    
// Game interface
private function game_interface($user_data) {
    $daily_spins = get_option('fruit_machine_daily_spins', 25);
    $remaining_spins = max(0, $daily_spins - $user_data['daily_spins_used']);
    $bet_amounts = get_option('fruit_machine_bet_amounts', array(1, 5, 10, 25));
    
    $bet_buttons = '';
    foreach ($bet_amounts as $bet) {
        $bet_buttons .= '<button class="bet-btn" data-bet="' . esc_attr($bet) . '">$' . esc_html($bet) . '</button>';
    }
    
    $output = '
<div class="fruit-machine-game" data-user-language="' . esc_attr($user_data['language']) . '">
    <div class="game-header">
        <div class="game-title">
            <span class="slot-icon">🎰</span>
            <span class="slot-text">' . __('FRUIT MACHINE', 'fruit-machine') . '</span>
        </div>
        <div class="user-controls">
            <div class="language-display">
                <select class="language-selector">
                    <option value="en">🇬🇧 ' . __('English', 'fruit-machine') . '</option>
                    <option value="nl">🇳🇱 ' . __('Nederlands', 'fruit-machine') . '</option>
                </select>
            </div>
            <button class="profile-btn" title="' . __('Profile', 'fruit-machine') . '">👤</button>
            <button class="leaderboard-btn" title="' . __('Monthly Leaderboard', 'fruit-machine') . '">🏆</button>
            <button class="history-btn" title="' . __('Spin History', 'fruit-machine') . '">📜</button>
        </div>
    </div>
    
    <div class="game-stats">
        <div class="credits-display" data-text-en="' . __('CREDITS', 'fruit-machine') . '" data-text-nl="' . __('CREDITS', 'fruit-machine') . '">
            ' . __('CREDITS', 'fruit-machine') . ' $' . number_format($user_data['credits'], 0) . '
        </div>
        <div class="win-display">' . __('WIN', 'fruit-machine') . ' $0</div>
    </div>
    
    <div class="spin-counter">
        <div class="spin-info">
            <span class="spin-label" data-text-en="' . __('Daily spins:', 'fruit-machine') . '" data-text-nl="' . __('Dagelijkse spins:', 'fruit-machine') . '">
                ' . __('Daily spins:', 'fruit-machine') . '
            </span>
            <span class="spin-count">' . $remaining_spins . '/' . $daily_spins . '</span>
        </div>
        <div class="spin-info">
            <span class="spin-label" data-text-en="' . __('BMAC spins:', 'fruit-machine') . '" data-text-nl="' . __('BMAC spins:', 'fruit-machine') . '">
                ' . __('BMAC spins:', 'fruit-machine') . '
            </span>
            <span class="spin-count">' . $user_data['bmac_spins'] . '</span>
        </div>
    </div>
    
    <!-- 5 REELS VERSION -->
    <div class="reels-container">
        <div class="reel">🍒</div>
        <div class="reel">🍊</div>
        <div class="reel">🍋</div>
        <div class="reel">🍉</div>
        <div class="reel">🍇</div>
    </div>
    
    <div class="win-info">
        <p data-text-en="🎯 ' . __('Win with 3+ matching symbols or cherries!', 'fruit-machine') . '" 
           data-text-nl="🎯 ' . __('Win met 3+ gelijke symbolen of kersen!', 'fruit-machine') . '">
            🎯 ' . __('Win with 3+ matching symbols or cherries!', 'fruit-machine') . '
        </p>
        <div class="payouts">
            <span data-text-en="5x = 500x" data-text-nl="5x = 500x">5x = 500x</span> |
            <span data-text-en="4x = 100x" data-text-nl="4x = 100x">4x = 100x</span> |
            <span data-text-en="3x = 50x" data-text-nl="3x = 50x">3x = 50x</span> |
            <span data-text-en="🍒 = 1x each" data-text-nl="🍒 = 1x elk">🍒 = 1x each</span>
        </div>
    </div>
    
    <div class="betting-section">
        <div class="current-bet-display">
            <span class="bet-text" data-text-en="' . __('BET:', 'fruit-machine') . '" 
                  data-text-nl="' . __('INZET:', 'fruit-machine') . '">
                ' . __('BET:', 'fruit-machine') . '
            </span> 
            <span class="bet-amount">$1</span>
        </div>
        
        <div class="bet-controls">
            ' . $bet_buttons . '
        </div>
    </div>
    
<!-- SPIN AND AUTO BUTTONS ON SAME LINE -->
<div class="control-buttons">
    <div class="spin-control">
        <button class="spin-btn" data-text-en="' . __('SPIN', 'fruit-machine') . '" data-text-nl="' . __('DRAAIEN', 'fruit-machine') . '">
            ' . __('SPIN', 'fruit-machine') . '
        </button>
    </div>
    
    <div class="auto-control">
        <button class="auto-btn" data-text-en="' . __('AUTO', 'fruit-machine') . '" data-text-nl="' . __('AUTO', 'fruit-machine') . '">
            ' . __('AUTO', 'fruit-machine') . '
        </button>
    </div>
</div>
    
    <div class="bmac-section">
        <p class="bmac-text" data-text-en="' . __('Support us via Buy Me A Coffee →', 'fruit-machine') . '" 
           data-text-nl="' . __('Steun ons via Buy Me A Coffee →', 'fruit-machine') . '">
            ' . __('Support us via Buy Me A Coffee →', 'fruit-machine') . '
           <a href="' . get_option('fruit_machine_bmac_url', 'https://buymeacoffee.com/nlbiertjenl') . '" target="_blank">
               ' . get_option('fruit_machine_bmac_url', 'https://buymeacoffee.com/nlbiertjenl') . '
           </a>
        </p>
        <button class="bmac-btn" data-text-en="' . __('Get 1500 Extra Spins!', 'fruit-machine') . '" 
                data-text-nl="' . __('Krijg 1500 Extra Spins!', 'fruit-machine') . '">
            ' . __('Get 1500 Extra Spins!', 'fruit-machine') . '
        </button>
    </div>
</div>

<!-- Modals -->
<div class="modal-overlay" id="leaderboard-modal" style="display:none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3 data-text-en="🏆 ' . __('Monthly Leaderboard', 'fruit-machine') . '" 
                data-text-nl="🏆 ' . __('Maandelijkse Leaderboard', 'fruit-machine') . '">
                🏆 ' . __('Monthly Leaderboard', 'fruit-machine') . '
            </h3>
            <button class="modal-close">&times;</button>
        </div>
        <div class="modal-body" id="leaderboard-content">
            ' . __('Loading...', 'fruit-machine') . '
        </div>
    </div>
</div>

<div class="modal-overlay" id="profile-modal" style="display:none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3 data-text-en="👤 ' . __('Player Profile', 'fruit-machine') . '" 
                data-text-nl="👤 ' . __('Speler Profiel', 'fruit-machine') . '">
                👤 ' . __('Player Profile', 'fruit-machine') . '
            </h3>
            <button class="modal-close">&times;</button>
        </div>
        <div class="modal-body" id="profile-content">
            ' . __('Loading...', 'fruit-machine') . '
        </div>
    </div>
</div>

<div class="modal-overlay" id="history-modal" style="display:none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3 data-text-en="📜 ' . __('Spin History', 'fruit-machine') . '" 
                data-text-nl="📜 ' . __('Spin Geschiedenis', 'fruit-machine') . '">
                📜 ' . __('Spin History', 'fruit-machine') . '
            </h3>
            <button class="modal-close">&times;</button>
        </div>
        <div class="modal-body" id="history-content">
            ' . __('Loading...', 'fruit-machine') . '
        </div>
    </div>
</div>';
    
    return $output;
}
    
    // Get user data
    private function get_user_data($user_id) {
        global $wpdb;
        
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE user_id = %d",
            $user_id
        ));
        
        if (!$row) {
            // Create new user record
            $wpdb->insert(
                $this->table_name,
                array(
                    'user_id' => $user_id,
                    'language' => 'en',
                    'daily_spins_used' => 0,
                    'total_spins' => 0,
                    'total_wins' => 0,
                    'bmac_spins' => 0,
                    'last_spin_date' => null
                )
            );
            
            // Give starting credits
            update_user_meta($user_id, 'fruit_machine_credits', 100);
            
            return array(
                'language' => 'en',
                'daily_spins_used' => 0,
                'total_spins' => 0,
                'total_wins' => 0,
                'bmac_spins' => 0,
                'credits' => 100
            );
        }
        
        $credits = get_user_meta($user_id, 'fruit_machine_credits', true);
        if ($credits === '') {
            $credits = 100;
            update_user_meta($user_id, 'fruit_machine_credits', $credits);
        }
        
        return array(
            'language' => $row->language ?: 'en',
            'daily_spins_used' => $row->daily_spins_used,
            'total_spins' => $row->total_spins,
            'total_wins' => $row->total_wins,
            'bmac_spins' => $row->bmac_spins,
            'credits' => floatval($credits)
        );
    }
    
    // Register REST API routes
    public function register_rest_routes() {
        register_rest_route('fruit-machine/v1', '/set-language', array(
            'methods' => 'POST',
            'callback' => array($this, 'api_set_language'),
            'permission_callback' => array($this, 'check_user_permission')
        ));
        
        register_rest_route('fruit-machine/v1', '/update-spins', array(
            'methods' => 'POST',
            'callback' => array($this, 'api_update_spins'),
            'permission_callback' => array($this, 'check_user_permission')
        ));
        
        register_rest_route('fruit-machine/v1', '/get-leaderboard', array(
            'methods' => 'GET',
            'callback' => array($this, 'api_get_leaderboard'),
            'permission_callback' => '__return_true'
        ));
        
        register_rest_route('fruit-machine/v1', '/get-profile', array(
            'methods' => 'GET',
            'callback' => array($this, 'api_get_profile'),
            'permission_callback' => array($this, 'check_user_permission')
        ));
        
        register_rest_route('fruit-machine/v1', '/add-bmac-spins', array(
            'methods' => 'POST',
            'callback' => array($this, 'api_add_bmac_spins'),
            'permission_callback' => array($this, 'check_user_permission')
        ));
        
        register_rest_route('fruit-machine/v1', '/get-history', array(
            'methods' => 'GET',
            'callback' => array($this, 'api_get_history'),
            'permission_callback' => array($this, 'check_user_permission')
        ));
    }
    
    // Check user permission for REST API
    public function check_user_permission($request = null) {
        return is_user_logged_in();
    }
    
    // AJAX: Set language
    public function ajax_set_language() {
        try {
            // Verify nonce
            if (!check_ajax_referer('wp_rest', 'nonce', false)) {
                throw new Exception(__('Security check failed', 'fruit-machine'));
            }
            
            if (!is_user_logged_in()) {
                throw new Exception(__('You must be logged in', 'fruit-machine'));
            }
            
            $user_id = get_current_user_id();
            $language = sanitize_text_field($_POST['language']);
            
            if (!in_array($language, array('en', 'nl'))) {
                throw new Exception(__('Invalid language selected', 'fruit-machine'));
            }
            
            global $wpdb;
            $result = $wpdb->update(
                $this->table_name,
                array('language' => $language),
                array('user_id' => $user_id)
            );
            
            if ($result === false) {
                throw new Exception(__('Database error', 'fruit-machine'));
            }
            
            wp_send_json_success(array(
                'language' => $language,
                'message' => __('Language saved successfully', 'fruit-machine')
            ));
            
        } catch (Exception $e) {
            wp_send_json_error(array(
                'message' => $e->getMessage()
            ));
        }
    }
    
    // Handle non-privileged AJAX requests
    public function ajax_nopriv_handler() {
        wp_send_json_error(array(
            'message' => __('You must be logged in', 'fruit-machine')
        ));
    }
    
    // AJAX: Get history
    public function ajax_get_history() {
        try {
            if (!is_user_logged_in()) {
                throw new Exception(__('You must be logged in', 'fruit-machine'));
            }
            
            if (!check_ajax_referer('wp_rest', 'nonce', false)) {
                throw new Exception(__('Security check failed', 'fruit-machine'));
            }
            
            $user_id = get_current_user_id();
            $limit = absint($_POST['limit'] ?? 20);
            
            global $wpdb;
            $history = $wpdb->get_results($wpdb->prepare(
                "SELECT spin_date, bet_amount, win_amount, symbols 
                 FROM {$this->history_table} 
                 WHERE user_id = %d 
                 ORDER BY spin_date DESC 
                 LIMIT %d",
                $user_id,
                $limit
            ));
            
            wp_send_json_success(array(
                'history' => $history
            ));
            
        } catch (Exception $e) {
            wp_send_json_error(array(
                'message' => $e->getMessage()
            ));
        }
    }
    
    // API: Set language (REST version)
    public function api_set_language($request) {
        try {
            $user_id = get_current_user_id();
            $language = sanitize_text_field($request['language']);
            
            if (!in_array($language, array('en', 'nl'))) {
                throw new Exception(__('Invalid language selected', 'fruit-machine'));
            }
            
            global $wpdb;
            $result = $wpdb->update(
                $this->table_name,
                array('language' => $language),
                array('user_id' => $user_id)
            );
            
            if ($result === false) {
                throw new Exception(__('Database error', 'fruit-machine'));
            }
            
            return array('success' => true, 'language' => $language);
            
        } catch (Exception $e) {
            return new WP_Error('server_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    // API: Update spins
    public function api_update_spins($request) {
        try {
            $user_id = get_current_user_id();
            $win_amount = floatval($request['win']);
            $bet_amount = floatval($request['bet']);
            $symbols = sanitize_text_field($request['symbols']);
            
            // Validate bet amount
            $allowed_bets = get_option('fruit_machine_bet_amounts', array(1, 5, 10, 25));
            if (!in_array($bet_amount, $allowed_bets)) {
                throw new Exception(__('Invalid bet amount', 'fruit-machine'));
            }
            
            global $wpdb;
            
            // Update user stats
            $today = date('Y-m-d');
            $user_data = $this->get_user_data($user_id);
            
            // Check if we need to reset daily spins
            if ($user_data['last_spin_date'] != $today) {
                $wpdb->update(
                    $this->table_name,
                    array('daily_spins_used' => 0),
                    array('user_id' => $user_id)
                );
            }
            
            // Update stats
            $wpdb->query($wpdb->prepare(
                "UPDATE {$this->table_name} 
                 SET daily_spins_used = daily_spins_used + 1,
                     total_spins = total_spins + 1,
                     total_wins = total_wins + %f,
                     last_spin_date = %s
                 WHERE user_id = %d",
                $win_amount,
                $today,
                $user_id
            ));
            
            // Update monthly stats for leaderboard
            $month_year = date('Y-m');
            $wpdb->query($wpdb->prepare(
                "INSERT INTO {$this->stats_table} (user_id, month_year, total_wins, total_spins, best_single_win)
                 VALUES (%d, %s, %f, 1, %f)
                 ON DUPLICATE KEY UPDATE 
                    total_wins = total_wins + VALUES(total_wins),
                    total_spins = total_spins + 1,
                    best_single_win = GREATEST(best_single_win, VALUES(best_single_win))",
                $user_id,
                $month_year,
                $win_amount,
                $win_amount
            ));
            
            // Record spin history
            $wpdb->insert(
                $this->history_table,
                array(
                    'user_id' => $user_id,
                    'bet_amount' => $bet_amount,
                    'win_amount' => $win_amount,
                    'symbols' => $symbols,
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
                )
            );
            
            // Update user credits
            $current_credits = get_user_meta($user_id, 'fruit_machine_credits', true);
            $new_credits = floatval($current_credits) - $bet_amount + $win_amount;
            update_user_meta($user_id, 'fruit_machine_credits', $new_credits);
            
            return array(
                'success' => true,
                'new_credits' => $new_credits,
                'remaining_daily_spins' => get_option('fruit_machine_daily_spins', 25) - ($user_data['daily_spins_used'] + 1)
            );
            
        } catch (Exception $e) {
            return new WP_Error('server_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    // API: Get leaderboard
    public function api_get_leaderboard($request) {
        try {
            $cache_key = 'fruit_machine_leaderboard_' . date('Y-m');
            $cached = get_transient($cache_key);
            
            if ($cached !== false) {
                return $cached;
            }
            
            global $wpdb;
            
            $month_year = date('Y-m');
            $results = $wpdb->get_results($wpdb->prepare(
                "SELECT s.user_id, s.total_wins, s.total_spins, s.best_single_win, u.display_name 
                 FROM {$this->stats_table} s 
                 LEFT JOIN {$wpdb->users} u ON s.user_id = u.ID 
                 WHERE s.month_year = %s 
                 ORDER BY s.total_wins DESC 
                 LIMIT 20",
                $month_year
            ));
            
            $leaderboard = array();
            $rank = 1;
            foreach ($results as $row) {
                $leaderboard[] = array(
                    'rank' => $rank,
                    'user_name' => $row->display_name ?: __('User #', 'fruit-machine') . $row->user_id,
                    'total_wins' => floatval($row->total_wins),
                    'total_spins' => intval($row->total_spins),
                    'best_win' => floatval($row->best_single_win)
                );
                $rank++;
            }
            
            $result = array(
                'success' => true,
                'month' => $month_year,
                'leaderboard' => $leaderboard
            );
            
            // Cache for 5 minutes
            set_transient($cache_key, $result, 5 * MINUTE_IN_SECONDS);
            
            return $result;
            
        } catch (Exception $e) {
            return new WP_Error('server_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    // API: Get profile
    public function api_get_profile($request) {
        try {
            $user_id = get_current_user_id();
            $user_data = $this->get_user_data($user_id);
            $user_info = get_userdata($user_id);
            
            return array(
                'success' => true,
                'profile' => array(
                    'username' => $user_info->user_login,
                    'display_name' => $user_info->display_name,
                    'email' => $user_info->user_email,
                    'language' => $user_data['language'],
                    'credits' => $user_data['credits'],
                    'total_spins' => $user_data['total_spins'],
                    'total_wins' => $user_data['total_wins'],
                    'daily_spins_used' => $user_data['daily_spins_used'],
                    'bmac_spins' => $user_data['bmac_spins'],
                    'member_since' => date_i18n(get_option('date_format'), strtotime($user_info->user_registered))
                )
            );
        } catch (Exception $e) {
            return new WP_Error('server_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    // API: Get history
    public function api_get_history($request) {
        try {
            $user_id = get_current_user_id();
            $limit = absint($request->get_param('limit') ?: 20);
            
            global $wpdb;
            $history = $wpdb->get_results($wpdb->prepare(
                "SELECT spin_date, bet_amount, win_amount, symbols 
                 FROM {$this->history_table} 
                 WHERE user_id = %d 
                 ORDER BY spin_date DESC 
                 LIMIT %d",
                $user_id,
                $limit
            ));
            
            return array(
                'success' => true,
                'history' => $history
            );
            
        } catch (Exception $e) {
            return new WP_Error('server_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    // API: Add BMAC spins
    public function api_add_bmac_spins($request) {
        try {
            $user_id = get_current_user_id();
            $payment_code = sanitize_text_field($request['payment_code']);
            
            // In a real implementation, verify payment code with Buy Me A Coffee API
            // For simulation, validate format
            if (empty($payment_code) || strlen($payment_code) < 10) {
                throw new Exception(__('Invalid payment code', 'fruit-machine'));
            }
            
            global $wpdb;
            $bmac_spins = get_option('fruit_machine_bmac_spins', 1500);
            $user_data = $this->get_user_data($user_id);
            
            $wpdb->query($wpdb->prepare(
                "UPDATE {$this->table_name} 
                 SET bmac_spins = bmac_spins + %d 
                 WHERE user_id = %d",
                $bmac_spins,
                $user_id
            ));
            
            // Record BMAC transaction
            $wpdb->insert(
                $this->history_table,
                array(
                    'user_id' => $user_id,
                    'bet_amount' => 0,
                    'win_amount' => 0,
                    'symbols' => 'BMAC_PURCHASE',
                    'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
                    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? ''
                )
            );
            
            return array(
                'success' => true,
                'message' => sprintf(__('Thank you for your support! %d spins have been added to your account.', 'fruit-machine'), $bmac_spins),
                'new_bmac_spins' => $user_data['bmac_spins'] + $bmac_spins
            );
            
        } catch (Exception $e) {
            return new WP_Error('server_error', $e->getMessage(), array('status' => 500));
        }
    }
    
    // Check user access
    public function check_user_access() {
        global $post;
        
        if (is_admin() || !is_singular()) {
            return;
        }
        
        if (has_shortcode($post->post_content, 'fruit_machine')) {
            if (!is_user_logged_in()) {
                wp_redirect(wp_login_url(get_permalink($post->ID)));
                exit;
            }
        }
    }
    
    // Add Buy Me A Coffee link to content
    public function add_buy_me_coffee_to_content($content) {
        if (is_single() && has_shortcode($content, 'fruit_machine')) {
            $bmac_url = get_option('fruit_machine_bmac_url', 'https://buymeacoffee.com/nlbiertjenl');
            $support_text = '
            <div class="fruit-machine-support">
                <strong>🎰 ' . __('Support the Fruit Machine:', 'fruit-machine') . '</strong>
                <p>' . __('Enjoying the game? Consider supporting us via', 'fruit-machine') . '
                   <a href="' . esc_url($bmac_url) . '" target="_blank">
                       ' . __('Buy Me A Coffee', 'fruit-machine') . '
                   </a> 
                   ' . __('to get 1500 extra spins!', 'fruit-machine') . '
                </p>
            </div>';
            
            $content .= $support_text;
        }
        
        return $content;
    }
    
    // Delete user data
    public function delete_user_data($user_id) {
        global $wpdb;
        
        $wpdb->delete($this->table_name, array('user_id' => $user_id));
        $wpdb->delete($this->stats_table, array('user_id' => $user_id));
        $wpdb->delete($this->history_table, array('user_id' => $user_id));
        delete_user_meta($user_id, 'fruit_machine_credits');
    }
}

new FruitMachine();