/**
 * FRUIT MACHINE GAME - frontend.js
 * VERSION 2.4.2 - Fixed sound icon overlap and button click sounds
 */

jQuery(document).ready(function($) {
    
    // ===== GAME STATE =====
    const gameState = {
        credits: 100,
        win: 0,
        currentBet: 1,
        isSpinning: false,
        autoSpin: false,
        soundEnabled: true,
        language: 'en', // Default to English
        dailySpinsUsed: 0,
        dailySpinsTotal: fruitMachineAjax.daily_spins || 25,
        bmacSpins: 0,
        userLoggedIn: fruitMachineAjax.is_logged_in || false,
        betAmounts: fruitMachineAjax.bet_amounts || [1, 5, 10, 25],
        lastSpinResults: []
    };
    
    // ===== 1. INITIALIZATION =====
    function initializeGame() {
        // Check if user is logged in
        if (!gameState.userLoggedIn) {
            // Login screen is already shown by PHP
            return;
        }
        
        // Auto-detect language from localStorage, browser, or database
        detectAndSetLanguage();
        
        // Setup game
        setupGame();
    }
    
    // ===== 2. LANGUAGE DETECTION =====
    function detectAndSetLanguage() {
        // Priority 1: Check localStorage (user preference)
        const savedLanguage = localStorage.getItem('fruitMachineLanguage');
        if (savedLanguage && (savedLanguage === 'en' || savedLanguage === 'nl')) {
            gameState.language = savedLanguage;
            return;
        }
        
        // Priority 2: Check database (from server)
        const serverLanguage = $('.fruit-machine-game').data('user-language');
        if (serverLanguage && (serverLanguage === 'en' || serverLanguage === 'nl')) {
            gameState.language = serverLanguage;
            localStorage.setItem('fruitMachineLanguage', serverLanguage);
            return;
        }
        
        // Priority 3: Check browser language
        const browserLang = navigator.language || navigator.userLanguage;
        if (browserLang) {
            if (browserLang.startsWith('nl')) {
                gameState.language = 'nl';
            } else {
                gameState.language = 'en'; // Default to English
            }
            localStorage.setItem('fruitMachineLanguage', gameState.language);
        }
        
        // Save to server if user is logged in
        if (gameState.userLoggedIn && gameState.language !== serverLanguage) {
            saveLanguageToServer(gameState.language);
        }
    }
    
    // ===== 3. SAVE LANGUAGE TO SERVER =====
    function saveLanguageToServer(language) {
        $.ajax({
            url: fruitMachineAjax.ajax_url,
            method: 'POST',
            data: {
                action: 'fruit_machine_set_language',
                nonce: fruitMachineAjax.nonce,
                language: language
            },
            success: function(response) {
                if (response.success) {
                    console.log('Language saved to server:', language);
                }
            },
            error: function() {
                console.log('Failed to save language to server');
            }
        });
    }
    
    // ===== 4. UPDATE LANGUAGE IN UI =====
    function updateLanguageUI() {
        // Update language selector
        $('.language-selector').val(gameState.language);
        
        // Update all elements with data-text attributes
        $('[data-text-en], [data-text-nl]').each(function() {
            const $el = $(this);
            const textEn = $el.data('text-en');
            const textNl = $el.data('text-nl');
            
            if (textEn && textNl) {
                if ($el.is('input, button, select, textarea')) {
                    $el.val(gameState.language === 'nl' ? textNl : textEn);
                } else {
                    $el.text(gameState.language === 'nl' ? textNl : textEn);
                }
            }
        });
        
        // Update credits display (special case)
        $('.credits-display').each(function() {
            const $el = $(this);
            const textEn = $el.data('text-en');
            const textNl = $el.data('text-nl');
            const credits = $el.text().match(/\$(\d+)/);
            
            if (credits) {
                const prefix = gameState.language === 'nl' ? (textNl || 'CREDITS') : (textEn || 'CREDITS');
                $el.text(prefix + ' $' + credits[1]);
            }
        });
    }
    
    // ===== 5. SOUND PRELOADING =====
    const sounds = {};
    const soundTypes = ['click', 'spin', 'win', 'lose', 'jackpot'];
    
    function preloadSounds() {
        const basePath = window.location.origin + '/wp-content/plugins/fruit-machine/assets/sounds/';
        
        soundTypes.forEach(type => {
            sounds[type] = new Audio();
            sounds[type].src = basePath + type + '.mp3';
            sounds[type].preload = 'auto';
            sounds[type].load();
            
            switch(type) {
                case 'click': sounds[type].volume = 0.4; break;
                case 'spin': sounds[type].volume = 0.5; break;
                case 'win': sounds[type].volume = 0.6; break;
                case 'lose': sounds[type].volume = 0.4; break;
                case 'jackpot': sounds[type].volume = 0.7; break;
            }
        });
    }
    
    // ===== 6. SOUND FUNCTIONS =====
    function playSound(type) {
        if (!gameState.soundEnabled) return;
        
        try {
            if (sounds[type]) {
                sounds[type].currentTime = 0;
                sounds[type].play().catch(function(error) {
                    console.log('Sound error:', type, error);
                });
            }
        } catch (e) {
            console.log('Audio failed:', type, e);
        }
    }
    
    function playToggleSound() {
        try {
            if (sounds['click']) {
                sounds['click'].currentTime = 0;
                sounds['click'].play();
            }
        } catch (e) {
            console.log('Toggle audio failed:', e);
        }
    }
    
    // ===== 7. SETUP GAME =====
    function setupGame() {
        preloadSounds();
        
        // Remove game preview elements
        $('.preview-btn, #preview-tab, .menu-preview, [class*="preview"]').remove();
        
        // Create sound toggle - Move it to a better position
        $('.fruit-machine-game').append(`
            <div class="sound-toggle ${gameState.soundEnabled ? 'sound-on' : 'sound-off'}" 
                 title="${gameState.language === 'nl' ? 'Geluid' : 'Sound'} ${gameState.soundEnabled ? 'ON' : 'OFF'} (M)">
            </div>
        `);
        
        // FIX: Move sound toggle further right to avoid overlapping history button
        repositionSoundToggle();
        
        // Setup event listeners
        setupEventListeners();
        
        // Update UI with current language
        updateLanguageUI();
        
        // Update game UI
        updateUI();
    }
    
// ===== 7a. REPOSITION SOUND TOGGLE - FIXED OVERLAP =====
function repositionSoundToggle() {
    const $soundToggle = $('.sound-toggle');
    const $gameContainer = $('.fruit-machine-game');
    
    if ($soundToggle.length && $gameContainer.length) {
        // Get the game header and user controls
        const $gameHeader = $('.game-header');
        const $userControls = $('.user-controls');
        
        if ($gameHeader.length && $userControls.length) {
            // Calculate vertical center position based on game header
            const gameHeaderHeight = $gameHeader.outerHeight();
            const gameHeaderTop = $gameHeader.position().top;
            
            // Center vertically within the game header
            const verticalCenter = gameHeaderTop + (gameHeaderHeight / 2);
            
            // Position the sound toggle
            $soundToggle.css({
                'position': 'absolute',
                'top': verticalCenter + 'px',
                'right': '25px',
                'transform': 'translateY(-50%)', // Center vertically
                'z-index': '1001'
            });
        }
    }
}
    
    // ===== 8. UPDATE UI =====
    function updateUI() {
        // Update displays
        const creditsText = gameState.language === 'nl' ? 'CREDITS' : 'CREDITS';
        $('.credits-display').text(creditsText + ' $' + Math.floor(gameState.credits));
        $('.win-display').text('WIN $' + Math.floor(gameState.win));
        $('.bet-amount').text('$' + gameState.currentBet);
        
        // Update spin counter
        const remainingSpins = Math.max(0, gameState.dailySpinsTotal - gameState.dailySpinsUsed);
        $('.spin-count').first().text(remainingSpins + '/' + gameState.dailySpinsTotal);
        $('.spin-count').last().text(gameState.bmacSpins);
        
        // Update bet buttons
        $('.bet-btn').removeClass('active');
        $('.bet-btn[data-bet="' + gameState.currentBet + '"]').addClass('active');
        
        // Update spin button
        const $spinBtn = $('.spin-btn');
        const canSpin = !gameState.isSpinning && 
                       gameState.credits >= gameState.currentBet && 
                       (remainingSpins > 0 || gameState.bmacSpins > 0);
        
        $spinBtn.prop('disabled', !canSpin);
        $spinBtn.text(gameState.isSpinning ? 
            (gameState.language === 'nl' ? 'DRAAIT...' : 'SPINNING...') : 
            $spinBtn.data(gameState.language === 'nl' ? 'text-nl' : 'text-en'));
        
        // Update auto button
        const autoText = gameState.autoSpin ? 
            (gameState.language === 'nl' ? 'STOP AUTO' : 'STOP AUTO') : 
            $('.auto-btn').data(gameState.language === 'nl' ? 'text-nl' : 'text-en');
        
        $('.auto-btn')
            .toggleClass('active', gameState.autoSpin)
            .text(autoText);
        
        // Update sound toggle
        $('.sound-toggle')
            .removeClass('sound-on sound-off')
            .addClass(gameState.soundEnabled ? 'sound-on' : 'sound-off')
            .attr('title', (gameState.language === 'nl' ? 'Geluid' : 'Sound') + ' ' + 
                  (gameState.soundEnabled ? 'ON' : 'OFF') + ' (M)');
    }
    
    // ===== 9. EVENT LISTENERS =====
    function setupEventListeners() {
        // Language selector change
        $('.language-selector').change(function(e) {
            e.preventDefault();
            const newLanguage = $(this).val();
            
            if (newLanguage !== gameState.language) {
                gameState.language = newLanguage;
                localStorage.setItem('fruitMachineLanguage', newLanguage);
                
                // Save to server if logged in
                if (gameState.userLoggedIn) {
                    saveLanguageToServer(newLanguage);
                }
                
                // Update UI
                updateLanguageUI();
                updateUI();
                
                // Play sound
                playSound('click');
            }
        });
        
        // Bet buttons
        $('.bet-btn').click(function(e) {
            e.preventDefault();
            playSound('click');
            gameState.currentBet = parseInt($(this).data('bet'));
            updateUI();
        });
        
        // Spin button
        $('.spin-btn').click(function(e) {
            e.preventDefault();
            if (gameState.isSpinning || gameState.credits < gameState.currentBet) return;
            
            // Check spins
            const remainingSpins = Math.max(0, gameState.dailySpinsTotal - gameState.dailySpinsUsed);
            if (remainingSpins <= 0 && gameState.bmacSpins <= 0) {
                showMessage(gameState.language === 'nl' ? 
                    'Geen spins meer! Koop extra spins via Buy Me A Coffee.' : 
                    'No spins left! Buy extra spins via Buy Me A Coffee.');
                return;
            }
            
            // Use BMAC spins if daily spins exhausted
            if (remainingSpins <= 0) {
                gameState.bmacSpins--;
            }
            
            playSound('spin');
            spinReels();
        });
        
        // Auto button
        $('.auto-btn').click(function(e) {
            e.preventDefault();
            playSound('click');
            gameState.autoSpin = !gameState.autoSpin;
            updateUI();
            
            if (gameState.autoSpin && !gameState.isSpinning && 
                gameState.credits >= gameState.currentBet) {
                setTimeout(function() {
                    if (gameState.autoSpin && !gameState.isSpinning && 
                        gameState.credits >= gameState.currentBet) {
                        playSound('spin');
                        spinReels();
                    }
                }, 500);
            }
        });
        
        // Sound toggle
        $(document).on('click', '.sound-toggle', function(e) {
            e.preventDefault();
            playToggleSound();
            gameState.soundEnabled = !gameState.soundEnabled;
            updateUI();
            localStorage.setItem('fruitMachineSound', gameState.soundEnabled);
        });
        
        // FIX: Add click sound to profile button
        $(document).on('click', '.profile-btn', function(e) {
            e.preventDefault();
            playSound('click'); // ADDED SOUND
            showProfile();
        });
        
        // FIX: Add click sound to leaderboard button
        $(document).on('click', '.leaderboard-btn', function(e) {
            e.preventDefault();
            playSound('click'); // ADDED SOUND
            showLeaderboard();
        });
        
        // FIX: Add click sound to history button (if exists)
        $(document).on('click', '.history-btn', function(e) {
            e.preventDefault();
            playSound('click'); // ADDED SOUND
            // If you have history functionality, add it here
            // For now, just show a message
            showMessage(gameState.language === 'nl' ? 'Spin geschiedenis komt binnenkort!' : 'Spin history coming soon!');
        });
        
        // BMAC button
        $('.bmac-btn').click(function(e) {
            e.preventDefault();
            playSound('click'); // ADDED SOUND
            window.open(fruitMachineAjax.bmac_url, '_blank');
        });
        
        // Modal close buttons - Add click sound
        $(document).on('click', '.modal-close, .modal-overlay', function(e) {
            if ($(e.target).hasClass('modal-overlay') || $(e.target).hasClass('modal-close')) {
                playSound('click'); // ADDED SOUND
                $('.modal-overlay').hide();
            }
        });
        
        // Keyboard shortcuts
        $(document).keydown(function(e) {
            if (e.key === ' ' && !gameState.isSpinning) {
                e.preventDefault();
                $('.spin-btn').click();
            }
            if (e.key >= '1' && e.key <= '4') {
                e.preventDefault();
                const index = parseInt(e.key) - 1;
                $('.bet-btn').eq(index).click();
            }
            if (e.key === 'a' || e.key === 'A') {
                e.preventDefault();
                $('.auto-btn').click();
            }
            if (e.key === 'm' || e.key === 'M') {
                e.preventDefault();
                $('.sound-toggle').click();
            }
            if (e.key === 'Escape') {
                playSound('click'); // ADDED SOUND
                $('.modal-overlay').hide();
            }
            if (e.key === 'l' || e.key === 'L') {
                e.preventDefault();
                // Toggle language
                const newLang = gameState.language === 'en' ? 'nl' : 'en';
                $('.language-selector').val(newLang).trigger('change');
            }
        });
        
        // Fix: Handle window resize to reposition sound toggle
        $(window).on('resize', function() {
            setTimeout(repositionSoundToggle, 100);
        });
    }
    
    // ===== 10. SPIN REELS - 5 REELS VERSION =====
    function spinReels() {
        gameState.isSpinning = true;
        gameState.credits -= gameState.currentBet;
        gameState.win = 0;
        updateUI();
        
        // Better symbols for better display
        const symbols = ['🍒', '🍊', '🍋', '🍉', '🍇', '🔔', '⭐', '7️⃣'];
        const results = [];
        
        // Animate each reel (now 5 reels)
        $('.reel').each(function(i) {
            const $reel = $(this);
            const spinTime = 1000 + (i * 200); // Reduced delay for 5 reels
            let spins = 0;
            const maxSpins = 15;
            
            const interval = setInterval(function() {
                $reel.text(symbols[Math.floor(Math.random() * symbols.length)]);
                spins++;
                
                if (spins >= maxSpins) {
                    clearInterval(interval);
                    const result = symbols[Math.floor(Math.random() * symbols.length)];
                    $reel.text(result);
                    results[i] = result;
                    
                    // When all 5 reels done
                    if (results.length === 5) {
                        setTimeout(function() {
                            calculateWin(results);
                        }, 500);
                    }
                }
            }, spinTime / maxSpins);
        });
    }
    
    // ===== 11. CALCULATE WIN - 5 REELS VERSION =====
    function calculateWin(results) {
        let multiplier = 0;
        let soundToPlay = 'lose';
        
        // Check win conditions for 5 reels
        const allSame = results.every(val => val === results[0]);
        const firstThreeSame = results[0] === results[1] && results[1] === results[2];
        const middleThreeSame = results[1] === results[2] && results[2] === results[3];
        const lastThreeSame = results[2] === results[3] && results[3] === results[4];
        const firstFourSame = results[0] === results[1] && results[1] === results[2] && results[2] === results[3];
        const lastFourSame = results[1] === results[2] && results[2] === results[3] && results[3] === results[4];
        
        if (allSame) {
            if (results[0] === '7️⃣') {
                multiplier = 500; // Mega jackpot for 5 sevens
                soundToPlay = 'jackpot';
            } else if (results[0] === '🔔') {
                multiplier = 200; // Big win for 5 bells
                soundToPlay = 'win';
            } else if (results[0] === '⭐') {
                multiplier = 100; // Good win for 5 stars
                soundToPlay = 'win';
            } else {
                multiplier = 50; // Regular win for 5 matching fruits
                soundToPlay = 'win';
            }
        } else if (firstFourSame || lastFourSame) {
            // 4 matching symbols
            if (results[0] === '7️⃣') {
                multiplier = 100;
                soundToPlay = 'jackpot';
            } else if (results[0] === '🔔') {
                multiplier = 50;
                soundToPlay = 'win';
            } else {
                multiplier = 25;
                soundToPlay = 'win';
            }
        } else if (firstThreeSame || middleThreeSame || lastThreeSame) {
            // 3 matching symbols
            if (results[0] === '7️⃣') {
                multiplier = 50;
                soundToPlay = 'win';
            } else if (results[0] === '🔔') {
                multiplier = 20;
                soundToPlay = 'win';
            } else if (results[0] === '⭐') {
                multiplier = 10;
                soundToPlay = 'win';
            } else {
                multiplier = 5;
                soundToPlay = 'win';
            }
        } else if (results.includes('🍒')) {
            // At least one cherry
            const cherryCount = results.filter(symbol => symbol === '🍒').length;
            multiplier = cherryCount; // $1 per cherry
            if (cherryCount > 0) soundToPlay = 'win';
        }
        
        gameState.win = gameState.currentBet * multiplier;
        
        // Save spin to server
        saveSpinResult(gameState.win, gameState.currentBet);
        
        if (gameState.win > 0) {
            gameState.credits += gameState.win;
            playSound(soundToPlay);
            
            let winMessage = '';
            if (soundToPlay === 'jackpot') {
                winMessage = gameState.language === 'nl' ? 
                    'MEGA JACKPOT! WIN $' + gameState.win : 
                    'MEGA JACKPOT! WIN $' + gameState.win;
            } else if (multiplier >= 100) {
                winMessage = gameState.language === 'nl' ? 
                    'SUPER WIN! $' + gameState.win : 
                    'SUPER WIN! $' + gameState.win;
            } else if (multiplier >= 50) {
                winMessage = gameState.language === 'nl' ? 
                    'GROTE WIN! $' + gameState.win : 
                    'BIG WIN! $' + gameState.win;
            } else {
                winMessage = gameState.language === 'nl' ? 
                    'GEWONNEN $' + gameState.win : 
                    'WIN $' + gameState.win;
            }
            
            showMessage(winMessage);
        } else {
            playSound('lose');
            showMessage(gameState.language === 'nl' ? 'GEEN WIN' : 'NO WIN');
        }
        
        gameState.isSpinning = false;
        updateUI();
        
        // Auto spin continue
        if (gameState.autoSpin && gameState.credits >= gameState.currentBet) {
            setTimeout(function() {
                if (gameState.autoSpin && !gameState.isSpinning && 
                    gameState.credits >= gameState.currentBet) {
                    playSound('spin');
                    spinReels();
                }
            }, 1000);
        } else if (gameState.autoSpin) {
            gameState.autoSpin = false;
            updateUI();
        }
    }
    
    // ===== 12. SAVE SPIN RESULT =====
    function saveSpinResult(winAmount, betAmount) {
        $.ajax({
            url: fruitMachineAjax.rest_url + 'update-spins',
            method: 'POST',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', fruitMachineAjax.nonce);
            },
            data: {
                win: winAmount,
                bet: betAmount
            },
            success: function(response) {
                if (response.success) {
                    gameState.credits = response.new_credits;
                    gameState.dailySpinsUsed = gameState.dailySpinsTotal - response.remaining_daily_spins;
                    updateUI();
                }
            },
            error: function() {
                console.log('Failed to save spin result');
            }
        });
    }
    
    // ===== 13. LEADERBOARD =====
    function showLeaderboard() {
        $('#leaderboard-modal').show();
        
        $.ajax({
            url: fruitMachineAjax.rest_url + 'get-leaderboard',
            method: 'GET',
            success: function(response) {
                if (response.success) {
                    let html = '<div class="leaderboard-container">';
                    html += '<h4>' + response.month + ' ' + 
                           (gameState.language === 'nl' ? 'Leaderboard' : 'Leaderboard') + '</h4>';
                    html += '<table class="leaderboard-table">';
                    html += '<thead><tr>' +
                           '<th>#</th>' +
                           '<th>' + (gameState.language === 'nl' ? 'Speler' : 'Player') + '</th>' +
                           '<th>' + (gameState.language === 'nl' ? 'Totaal Gewonnen' : 'Total Wins') + '</th>' +
                           '<th>' + (gameState.language === 'nl' ? 'Spins' : 'Spins') + '</th>' +
                           '<th>' + (gameState.language === 'nl' ? 'Beste Win' : 'Best Win') + '</th>' +
                           '</tr></thead>';
                    html += '<tbody>';
                    
                    response.leaderboard.forEach(function(player) {
                        html += '<tr>';
                        html += '<td>' + player.rank + '</td>';
                        html += '<td>' + player.user_name + '</td>';
                        html += '<td>$' + player.total_wins.toFixed(2) + '</td>';
                        html += '<td>' + player.total_spins + '</td>';
                        html += '<td>$' + player.best_win.toFixed(2) + '</td>';
                        html += '</tr>';
                    });
                    
                    html += '</tbody></table></div>';
                    $('#leaderboard-content').html(html);
                }
            },
            error: function() {
                $('#leaderboard-content').html(
                    '<p>' + (gameState.language === 'nl' ? 
                    'Kan leaderboard niet laden' : 
                    'Failed to load leaderboard') + '</p>'
                );
            }
        });
    }
    
    // ===== 14. PROFILE =====
    function showProfile() {
        $('#profile-modal').show();
        
        $.ajax({
            url: fruitMachineAjax.rest_url + 'get-profile',
            method: 'GET',
            beforeSend: function(xhr) {
                xhr.setRequestHeader('X-WP-Nonce', fruitMachineAjax.nonce);
            },
            success: function(response) {
                if (response.success) {
                    const p = response.profile;
                    let html = '<div class="profile-container">';
                    html += '<div class="profile-info">';
                    html += '<p><strong>' + (gameState.language === 'nl' ? 'Gebruikersnaam:' : 'Username:') + '</strong> ' + p.username + '</p>';
                    html += '<p><strong>' + (gameState.language === 'nl' ? 'Weergavenaam:' : 'Display Name:') + '</strong> ' + p.display_name + '</p>';
                    html += '<p><strong>' + (gameState.language === 'nl' ? 'Taal:' : 'Language:') + '</strong> ' + 
                           (p.language === 'nl' ? 'Nederlands 🇳🇱' : 'English 🇬🇧') + '</p>';
                    html += '<p><strong>' + (gameState.language === 'nl' ? 'Lid sinds:' : 'Member Since:') + '</strong> ' + p.member_since + '</p>';
                    html += '</div>';
                    
                    html += '<div class="profile-stats">';
                    html += '<h4>' + (gameState.language === 'nl' ? 'Spel Statistieken' : 'Game Statistics') + '</h4>';
                    html += '<p><strong>' + (gameState.language === 'nl' ? 'Credits:' : 'Credits:') + '</strong> $' + p.credits.toFixed(2) + '</p>';
                    html += '<p><strong>' + (gameState.language === 'nl' ? 'Totaal Spins:' : 'Total Spins:') + '</strong> ' + p.total_spins + '</p>';
                    html += '<p><strong>' + (gameState.language === 'nl' ? 'Totaal Gewonnen:' : 'Total Wins:') + '</strong> $' + p.total_wins.toFixed(2) + '</p>';
                    html += '<p><strong>' + (gameState.language === 'nl' ? 'Dagelijkse Spins Gebruikt:' : 'Daily Spins Used:') + '</strong> ' + 
                           p.daily_spins_used + '/' + gameState.dailySpinsTotal + '</p>';
                    html += '<p><strong>' + (gameState.language === 'nl' ? 'BMAC Spins Over:' : 'BMAC Spins Left:') + '</strong> ' + p.bmac_spins + '</p>';
                    html += '</div>';
                    
                    html += '<div class="profile-actions">';
                    html += '<p><em>' + (gameState.language === 'nl' ? 
                           'Verander taal via de dropdown bovenaan' : 
                           'Change language via dropdown at the top') + '</em></p>';
                    html += '</div></div>';
                    
                    $('#profile-content').html(html);
                }
            },
            error: function() {
                $('#profile-content').html(
                    '<p>' + (gameState.language === 'nl' ? 
                    'Kan profiel niet laden' : 
                    'Failed to load profile') + '</p>'
                );
            }
        });
    }
    
    // ===== 15. MESSAGES =====
    function showMessage(text) {
        const $msg = $('<div class="game-message">' + text + '</div>').appendTo('body');
        $msg.addClass('show');
        
        setTimeout(function() {
            $msg.removeClass('show');
            setTimeout(function() {
                $msg.remove();
            }, 500);
        }, 2000);
    }
    
    // ===== 16. INITIALIZE =====
    // Load sound setting from localStorage
    const savedSound = localStorage.getItem('fruitMachineSound');
    if (savedSound !== null) {
        gameState.soundEnabled = (savedSound === 'true');
    }
    
    // Initialize game
    initializeGame();
});