<?php
/**
 * Uninstall Fruit Machine
 * 
 * @package FruitMachine
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Prevent direct access
if (!current_user_can('activate_plugins')) {
    wp_die(__('You do not have sufficient permissions to perform this action.', 'fruit-machine'));
}

global $wpdb;

// Delete database tables
$tables = array(
    $wpdb->prefix . 'fruit_machine_users',
    $wpdb->prefix . 'fruit_machine_stats',
    $wpdb->prefix . 'fruit_machine_history'
);

foreach ($tables as $table) {
    $wpdb->query("DROP TABLE IF EXISTS {$table}");
}

// Delete user meta
$wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE 'fruit_machine_%'");

// Delete options
$options = array(
    'fruit_machine_daily_spins',
    'fruit_machine_bmac_spins',
    'fruit_machine_bmac_url',
    'fruit_machine_leaderboard_reset',
    'fruit_machine_bet_amounts',
    'fruit_machine_db_version',
    'fruit_machine_activation_notice'
);

foreach ($options as $option) {
    delete_option($option);
}

// Delete transients
$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_fruit_machine_%'");
$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_fruit_machine_%'");

// Clear any cached data
wp_cache_flush();

// Log uninstallation
error_log('Fruit Machine plugin uninstalled on ' . date('Y-m-d H:i:s'));